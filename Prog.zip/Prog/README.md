Architettura Master-Worker:

L'applicazione è strutturata seguendo un'architettura master-worker, dove un Master coordina il lavoro e assegna compiti ai Worker.
Il master assegna i compiti di map e reduce ai worker.
Fasi del MapReduce:

Map: Ogni worker riceve dal master una parte (chiamata "chunk") dei dati da ordinare. Il worker esegue l'ordinamento sui dati del chunk assegnato.
Shuffle: I worker che hanno completato il compito di map inviano i risultati intermedi ad altri worker responsabili della fase di reduce. Questo avviene partizionando i dati intermedi.
Reduce: I worker che ricevono i risultati intermedi (i dati ordinati dai worker di map) eseguono una fusione di questi risultati per ottenere l'output finale ordinato. Ogni worker di reduce scrive il risultato finale in un file.
Punti di sincronizzazione:

La fase di reduce non può iniziare finché tutti i worker di map non hanno completato la loro elaborazione. Questo richiede un punto di sincronizzazione tra le fasi di map e reduce.
Assunzioni semplificative:

Nessun fallimento del master o dei worker durante l'elaborazione.
Il set di worker è definito all'inizio e non cambia durante l'esecuzione. Inoltre, le porte di comunicazione sono predefinite in un file di configurazione.